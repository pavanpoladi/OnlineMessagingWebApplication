import os
import requests
import time

from flask import Flask, jsonify, render_template, request, redirect, url_for, session
from flask_socketio import SocketIO, emit
from datetime import datetime

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY")
socketio = SocketIO(app)


#Create list of displayNames and list of channels, with default channel
displayNames = []
channels = ["default"]

#create empty messages dictionary and set numOfMessages=0
messages = {}
numOfMessages = 0

#Create list of messages for every channel
for channel in channels:
    messages[channel] = []

#Each message object will have a message, user, messageID, and time
class message:
    def __init__(self, messageText, username, messageID):
        self.message = messageText
        self.user = username
        self.messageID = messageID
        self.time = str(datetime.now()) #Sets message time to current time

    def printMessageInfo(self):
        return [self.message, self.time, self.user]


#Default Route
#if user has already signed in with a displayName it will take them to the chatbox, otherwise it will send them to the login page
@app.route("/")
def index():
    try:
        if session["displayName"]:
            return render_template("chatBox.html", username = session["displayName"], channels = channels)
    except KeyError:
        return redirect(url_for("login")) #Redirects them to the login page


#Login Route
@app.route("/login", methods = ["GET", "POST"])
def login():
    try:
        #This will essentially logout the user if he already has a displayName
        displayName = session["displayName"]

        for name in displayNames:
            if name == displayName:
                displayNames.pop(displayNames.index(name)) #removes the displayName equal to the session DisplayName from the list of displayName
    except:
        #New User needs to login
        print("New User can now login")

    session.clear()

    if request.method == "GET":
        return render_template("login.html")
    else:
        #get the displayName, maker sure its not empty or taken, change session's displayName, add the displayName to the list of displayNames, and call the index function
        name = request.form.get("username")
        if name == "":
            return render_template("login.html") #Send user back to login page bcs user didn't enter display name
        else:
            if name in displayNames:
                return render_template("login.html") #Send user back to login page bcs displayName is already taken
            else:
                session["displayName"] = name
                displayNames.append(name)
                return redirect(url_for("index")) #Redirects them to the home page and calls the respective index function


#The 3 functions below are called by the Javascript from the client side 
 #Checks if displayName exists
@app.route("/displayName", methods = ["GET"])
def displayName():
    name = request.args.get("name")
    if name in displayNames:
        return "True"
    else:
        return "False"


#Get Messages in json format from currentChannel
@app.route("/getMessages", methods = ["GET"])
def getMessages():
    channel = request.args.get("currentChannel")
    data = []
    for message in messages[channel]:
        data.append(message.printMessageInfo())
    return jsonify({'data': data})


#Check if Channel Exists
@app.route("/isChannel", methods = ["GET"])
def isChannel():
    channelName = request.args.get("channelInputName")
    if channelName in channels:
        return "True"
    else:
        return "False"


#This method allows the user to create a channel
@socketio.on("createChannel")
def createChannel(data):
    nameOfNewChannel = data["nameOfNewChannel"]
    if nameOfNewChannel not in channels:
        channels.append(nameOfNewChannel)
        messages[nameOfNewChannel] = []
        emit("addChannel", {"nameOfNewChannel": nameOfNewChannel}, broadcast = True) #emit function used to let users know about info like creating new channels and sending messages


#This method allows the user to send Messages
@socketio.on("sendMessage")
def sendMessage(data):
    global numOfMessages
    messageText = data["messageText"]
    username = data["username"]
    currentChannel = data["currentChannel"]

    newMessage = message(messageText, username, numOfMessages)
    numOfMessages += 1
    messages[currentChannel].append(newMessage)
    newMessageInfo = newMessage.printMessageInfo()
    emit("addMessage", {"messageText": newMessageInfo[0], "messageTime": newMessageInfo[1], "messageUsername": newMessageInfo[2], "channel": currentChannel}, broadcast = True)


#makes sure that this file is only run if it is not being imported from somewhere else
if __name__ == "__main__":
    socketio.run(app)